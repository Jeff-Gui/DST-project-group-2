import DST2.Group2.DAO.DrugDAO;
import DST2.Group2.DAO.UserDAO;
import DST2.Group2.bean.UserBean;
import org.springframework.beans.factory.annotation.Autowired;

public class registerTest {
    public static void main(String[] args){
        UserDAO userDAO = new UserDAO();
        UserBean user = new UserBean("Jeff", "jeff");
        System.out.println(userDAO.searchUser(user)[1]);
    }

}
